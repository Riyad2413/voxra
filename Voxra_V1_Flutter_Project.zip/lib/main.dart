import 'package:flutter/material.dart';

void main() => runApp(const VoxraApp());

class VoxraApp extends StatelessWidget {
  const VoxraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Voxra',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF080A10),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF7C5CFF),
        brightness: Brightness.dark,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF151821),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
      ),
    ),
    home: const LoginScreen(),
  );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final u=TextEditingController(), p=TextEditingController();
  bool hide=true;
  void login() {
    if(u.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Username লিখুন'))); return;}
    Navigator.pushReplacement(context, MaterialPageRoute(
      builder:(_)=>HomeScreen(username:u.text.trim())));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(28), child: Column(children:[
      const SizedBox(height:30),
      Container(width:82,height:82,
        decoration:BoxDecoration(borderRadius:BorderRadius.circular(25),
        gradient:const LinearGradient(colors:[Color(0xFF7C5CFF),Color(0xFF4D8DFF)])),
        child:const Icon(Icons.graphic_eq_rounded,size:45)),
      const SizedBox(height:20),
      const Text('VOXRA',style:TextStyle(fontSize:34,fontWeight:FontWeight.bold,letterSpacing:5)),
      const SizedBox(height:6),
      const Text('Talk Private. Talk Different.',style:TextStyle(color:Colors.white54)),
      const SizedBox(height:50),
      TextField(controller:u,decoration:const InputDecoration(
        prefixIcon:Icon(Icons.person_outline),hintText:'Username / Voxra ID')),
      const SizedBox(height:16),
      TextField(controller:p,obscureText:hide,decoration:InputDecoration(
        prefixIcon:const Icon(Icons.lock_outline),hintText:'Password',
        suffixIcon:IconButton(icon:Icon(hide?Icons.visibility_off:Icons.visibility),
        onPressed:()=>setState(()=>hide=!hide)))),
      const SizedBox(height:25),
      SizedBox(width:double.infinity,height:55,child:ElevatedButton(
        onPressed:login,style:ElevatedButton.styleFrom(
        backgroundColor:const Color(0xFF7C5CFF),shape:RoundedRectangleBorder(
        borderRadius:BorderRadius.circular(16))),child:const Text('LOGIN',
        style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1)))),
      const SizedBox(height:15),
      TextButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content:Text('Create Account পরের Version-এ যুক্ত হবে'))),
        child:const Text('Create Account')),
    ]))));
}

class HomeScreen extends StatelessWidget {
  final String username;
  const HomeScreen({super.key,required this.username});
  static const users=[['Ahmed786',true],['Sami22',true],['Rahim55',false]];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(backgroundColor:Colors.transparent,elevation:0,
      title:const Text('VOXRA',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:3)),
      actions:[IconButton(onPressed:(){},icon:const Icon(Icons.settings_outlined))]),
    body:Padding(padding:const EdgeInsets.symmetric(horizontal:18),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
      const SizedBox(height:10),
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(20),
        gradient:const LinearGradient(colors:[Color(0xFF19152D),Color(0xFF111522)])),
        child:Row(children:[const CircleAvatar(radius:28,backgroundColor:Color(0xFF7C5CFF),
        child:Icon(Icons.person)),const SizedBox(width:14),Expanded(child:Column(
        crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(username,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
        const SizedBox(height:4),const Text('VX-7K29-481',style:TextStyle(color:Colors.white54,fontSize:12))
      ]))])),
      const SizedBox(height:20),
      const TextField(decoration:InputDecoration(prefixIcon:Icon(Icons.search),
        hintText:'Search username / ID',suffixIcon:Icon(Icons.person_add_alt_1))),
      const SizedBox(height:25),
      const Text('Online Friends',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      Expanded(child:ListView.builder(itemCount:users.length,itemBuilder:(c,i){
        final name=users[i][0] as String, online=users[i][1] as bool;
        return Container(margin:const EdgeInsets.only(bottom:10),
          decoration:BoxDecoration(color:const Color(0xFF12151D),borderRadius:BorderRadius.circular(18)),
          child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:5),
            leading:CircleAvatar(radius:25,backgroundColor:const Color(0xFF292D3A),
              child:Icon(Icons.person,color:online?Colors.white:Colors.white38)),
            title:Text(name,style:const TextStyle(fontWeight:FontWeight.bold)),
            subtitle:Text(online?'Online':'Offline',style:TextStyle(
              color:online?Colors.greenAccent:Colors.white38)),
            trailing:IconButton(icon:const Icon(Icons.mic_rounded,color:Color(0xFF8D70FF)),
              onPressed:online?()=>Navigator.push(c,MaterialPageRoute(
                builder:(_)=>CallScreen(username:name))):null)));
      }))
    ]),
    bottomNavigationBar:const BottomNavigationBar(currentIndex:0,
      backgroundColor:Color(0xFF0D1017),selectedItemColor:Color(0xFF9A80FF),
      unselectedItemColor:Colors.white38,items:[
      BottomNavigationBarItem(icon:Icon(Icons.home_rounded),label:'Home'),
      BottomNavigationBarItem(icon:Icon(Icons.call_rounded),label:'Calls'),
      BottomNavigationBarItem(icon:Icon(Icons.person_rounded),label:'Profile')]));
}

class CallScreen extends StatefulWidget {
  final String username; const CallScreen({super.key,required this.username});
  @override State<CallScreen> createState()=>_CallScreenState();
}
class _CallScreenState extends State<CallScreen>{
  bool muted=false,speaker=false; String voice='DEEP';
  final voices=['NORMAL','DEEP','HEAVY','LOW'];
  @override Widget build(BuildContext context)=>Scaffold(
    body:SafeArea(child:Column(children:[
      Align(alignment:Alignment.topLeft,child:IconButton(
        icon:const Icon(Icons.arrow_back),onPressed:()=>Navigator.pop(context))),
      const Spacer(),
      Container(width:105,height:105,decoration:BoxDecoration(shape:BoxShape.circle,
        gradient:const LinearGradient(colors:[Color(0xFF7C5CFF),Color(0xFF4D8DFF)])),
        child:const Icon(Icons.person,size:55)),
      const SizedBox(height:22),
      Text(widget.username,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),const Text('Calling...',style:TextStyle(color:Colors.greenAccent)),
      const SizedBox(height:10),const Text('00:24',style:TextStyle(color:Colors.white54)),
      const SizedBox(height:35),
      Container(margin:const EdgeInsets.symmetric(horizontal:35),padding:const EdgeInsets.all(18),
        decoration:BoxDecoration(color:const Color(0xFF131720),borderRadius:BorderRadius.circular(22)),
        child:Column(children:[const Row(mainAxisAlignment:MainAxisAlignment.center,
          children:[Icon(Icons.graphic_eq,color:Color(0xFF9A80FF)),SizedBox(width:8),
          Text('VOICE EFFECT',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1))]),
          const SizedBox(height:15),Wrap(spacing:8,children:voices.map((x)=>ChoiceChip(
            label:Text(x),selected:voice==x,onSelected:(_)=>setState(()=>voice=x))).toList())])),
      const Spacer(),
      Row(mainAxisAlignment:MainAxisAlignment.center,children:[
        _btn(muted?Icons.mic_off:Icons.mic,'Mute',muted,()=>setState(()=>muted=!muted)),
        const SizedBox(width:25),_btn(speaker?Icons.volume_up:Icons.volume_down,'Speaker',speaker,
          ()=>setState(()=>speaker=!speaker)),const SizedBox(width:25),
        _btn(Icons.call_end,'End',false,()=>Navigator.pop(context),red:true)]),
      const SizedBox(height:35)
    ])));
  Widget _btn(IconData icon,String label,bool active,VoidCallback tap,{bool red=false})=>Column(
    children:[GestureDetector(onTap:tap,child:Container(width:62,height:62,
      decoration:BoxDecoration(shape:BoxShape.circle,color:red?Colors.redAccent:
      active?const Color(0xFF7C5CFF):const Color(0xFF1A1E28)),
      child:Icon(icon,size:27)),),const SizedBox(height:8),
      Text(label,style:const TextStyle(color:Colors.white54,fontSize:12))]);
}
