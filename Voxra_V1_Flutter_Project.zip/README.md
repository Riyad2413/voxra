# Voxra V1
Flutter UI prototype: Login -> Home -> Call Screen.

This build is a UI prototype only. It does not yet provide real internet voice calling or real-time voice effects.

Build:
flutter pub get
flutter build apk --release

APK output:
build/app/outputs/flutter-apk/app-release.apk
